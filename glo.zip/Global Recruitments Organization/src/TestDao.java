import static org.junit.Assert.*;


import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;


import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.EnquiryException;



public class TestDao {

	static ContactBookDaoImpl dao;

	static EnquiryBean enquiry;



	@BeforeClass

	public static void initialize(){

	 System.out.println("in before class");

	 dao=new ContactBookDaoImpl();

	 enquiry=new EnquiryBean();

	}

	@Test

	public void testAdddraftDetails() throws EnquiryException{

	 assertNotNull(dao.addEnquiry(enquiry));

	}

	@Ignore

	@Test

	public void testAdddraftDetails1() throws EnquiryException{

	 assertEquals(10115,dao.addEnquiry(enquiry));

	}

	@Test

	public void testAdddraftDetails2() throws EnquiryException{
		enquiry.setfName("Akshay");
		enquiry.setlName("Joshi");
		enquiry.setContactNo("9876545678");
		enquiry.setpLocation("Pune");
		 assertTrue("data inserted");
		
	}


	private void assertTrue(String string) {

	 // TODO Auto-generated method stub



	}

	@Test

	public void testByid() throws EnquiryException {

	 assertNotNull(dao.getEnquiryDetails(10115));

	}
}

/*	@Ignore

	@Test

	public void testByid1() throws EnquiryException {

	 assertEquals("edg",dao.getDemandDraftDetails(10013).getCustomer_Name());

}
*/