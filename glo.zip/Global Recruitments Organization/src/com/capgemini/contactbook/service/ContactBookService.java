package com.capgemini.contactbook.service;

import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.EnquiryException;

public interface ContactBookService {
	
	public int addEnquiry(EnquiryBean enqry) throws EnquiryException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws EnquiryException;
	public boolean isValidEnquiry(EnquiryBean enqry) throws EnquiryException;

}
