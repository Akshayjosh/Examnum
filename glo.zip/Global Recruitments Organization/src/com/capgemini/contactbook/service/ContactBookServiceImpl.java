package com.capgemini.contactbook.service;

import java.util.regex.Pattern;


import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.EnquiryException;


public class ContactBookServiceImpl implements ContactBookService{
	
	ContactBookDao dao=new ContactBookDaoImpl();

	@Override
	public int addEnquiry(EnquiryBean enqry) throws EnquiryException{
		// TODO Auto-generated method stub
		return dao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws EnquiryException{
		// TODO Auto-generated method stub
		return dao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws EnquiryException{
		Boolean flag=true;
		String firstName="^[A-Z][a-z]{4,19}$";
		String lastName="^[A-Z][a-z]{4,19}$";
		String phonenoEx="^[6-9][0-9]{9}$";
		//if(!student.getName().matches(regx))
		if(!Pattern.matches((firstName),enqry.getfName()))
		{
			flag=false;
			try {
				throw new EnquiryException("customer first name should start with capitalletters and size should be 5 to 20 ......!");
			} catch (EnquiryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return flag;
			}
		}
		
		else if(!Pattern.matches((lastName),enqry.getlName()))
		{
			flag=false;
			try {
				throw new EnquiryException("customer last name should start with capitalletters and size should be 5 to 20 ......!");
			} catch (EnquiryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else	if(!Pattern.matches(phonenoEx,enqry.getContactNo()))
		{	
			flag=false;
			try {
				throw new EnquiryException("enter valid mobile number...!");
			} catch (EnquiryException e) {
				
				e.printStackTrace();
			}
		}

	

		return flag;
	}

}
