package com.capgemini.contactbook.exception;

public class EnquiryException extends Exception{

	public EnquiryException(String string) {
		// TODO Auto-generated constructor stub
	}

}
