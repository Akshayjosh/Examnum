package com.capgemini.contactbook.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.EnquiryException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;


public class main {
	
public static void main(String[] args)  {
		
		Scanner sc=new Scanner(System.in);
		do {
			
			System.out.println();
			System.out.println();
			System.out.println("----------------------------");
			System.out.println("1.Add Purchase Details");
			System.out.println("2.Exit");
			System.out.println("enter your choice :");
			String choice = sc.next();
			if(Pattern.matches("[1-5]",choice)){
			switch (choice) {
			case "1" :
				ContactBookService service=new ContactBookServiceImpl();
				
					System.out.println("Enter First Name");
						String fName=sc.next();
						System.out.println("Enter Lat Name:");
						String lName=sc.next();
						
						System.out.println("Enter Phone Number:");
						String phoneNo=sc.next();
						
						System.out.println("Enter city:");
						String city=sc.next();
			
				
						EnquiryBean enquiry = new EnquiryBean(fName,lName,phoneNo,city);		

						try {                                                                                                           
							if(service.isValidEnquiry(enquiry))
							{
								
			
			
				int	enquiry1=service.addEnquiry(enquiry);
					System.out.println("entered details successfully with purchaseid :"+enquiry1);
				}
						}
							
							
							 catch (Exception e1) {

							System.err.println(e1.getMessage());
						}
						
						break;
						
			case "2" :
				ContactBookService service1=new ContactBookServiceImpl();
				System.out.println("Enter transaction ID");
				int enquiryId=sc.nextInt();
				
			
				EnquiryBean e1;
				
				try {
					e1 = service1.getEnquiryDetails(enquiryId);
					System.out.println("enquiryId\t"+e1.getEnqryId()+
							"FName\t"+e1.getfName()+"\nLName\t"+e1.getlName()
							+"\nPhone number\t"+e1.getContactNo()+"\nCity\t"+e1.getpLocation());
					
				} catch (EnquiryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					
				break;
				
			/*case "4" :
				
				List<DemandDraft> dlist;
				IDemandDraftService Draft2=new DemandDraftService();
				try {
					dlist = Draft2.getAllDemandDraftDetails();
					if(dlist.size()==0)
						System.out.println("no details available");
					else {
						for(DemandDraft p1:dlist)
							System.out.println(p1);
					}
					
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
					break;
				
		*/
			case "5":
				System.exit(0);
				break;

			default:
				System.out.println("enter valid choice ");

			}
			}else System.err.println("enter a valid choice ");
		} while (true);
		
		
		
		
		
		
		
		


}
	
	
}
