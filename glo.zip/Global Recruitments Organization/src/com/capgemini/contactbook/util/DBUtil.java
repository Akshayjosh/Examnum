package com.capgemini.contactbook.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;



public class DBUtil {
	
	private static Connection connection;
	static Logger logger= Logger.getLogger(DBUtil.class);
	public static Connection getConnection() {
		logger.info("start of getConnection method ");
		if (connection == null) {
			try {
				FileReader reader = new FileReader("resources\\jdbc.properties");
				Properties properties = new Properties();
				properties.load(reader);
				Class.forName(properties.getProperty("driver"));
				
				connection = DriverManager.getConnection(
						properties.getProperty("url"),
						properties.getProperty("userName"),
						properties.getProperty("password"));

			}catch(IOException e){
				e.printStackTrace();
			}
			catch (ClassNotFoundException e) {
				logger.error("Problem occured while loading the driver class"+e.getMessage());
				e.printStackTrace();
			}catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		logger.info("end of getConnection method");
		return connection;
	}

}


