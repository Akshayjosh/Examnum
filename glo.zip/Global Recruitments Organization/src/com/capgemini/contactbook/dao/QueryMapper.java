package com.capgemini.contactbook.dao;

public class QueryMapper {

	public static final String INSERT_PURCHASE_DETAILS_QUERY = "insert into enquiry values(?,?,?,?,?)";
	public static final String GENERATE_PURCHASEID_SEQUENCE = "SELECT enquiries.NEXTVAL FROM dual";
	public static final String RETRIVE_PURCHASE_DETAILS_WITH_PURCHASEID_QUERY = "SELECT  firstname, lastname, contactno, city from enquiry where enquiryid=?";

}
