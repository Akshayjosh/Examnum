package com.capgemini.contactbook.dao;

import java.sql.Connection;



import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.contactbook.beans.EnquiryBean;
import com.capgemini.contactbook.exception.EnquiryException;
import com.capgemini.contactbook.util.DBUtil;



public class ContactBookDaoImpl implements ContactBookDao{
	

Connection conn = null;

	
	Logger logger=Logger.getRootLogger();


	private EnquiryBean enqry;
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resources/jdbc.properties");
	PropertyConfigurator.configure("resources/log4j.properties");
	
	}
	

	@Override
	public int addEnquiry(EnquiryBean enqry) throws EnquiryException{
		
		int transactionId=GeneratePurchaseId();
		try {
			
			conn = DBUtil.getConnection();
			
			conn.setAutoCommit(false);
			logger.info("connection established successfully");

			
			PreparedStatement preparedStatement = conn.prepareStatement(QueryMapper.INSERT_PURCHASE_DETAILS_QUERY);
			preparedStatement.setInt(1, transactionId);
			
			preparedStatement.setString(2, enqry.getfName());
			preparedStatement.setString(3, enqry.getlName());
			preparedStatement.setString(4, enqry.getContactNo());
			preparedStatement.setString(5, enqry.getpLocation());
			
			enqry.setEnqryId(transactionId);;
			preparedStatement.executeUpdate();
			logger.info("Purchase details inserted successfull");
			conn.commit();
			
			// conn.setAutoCommit(true);
			 
		} catch (SQLException e) {
			logger.error("Not valid");
			
		}

		
		return transactionId;
			
	}
	
	
	public int GeneratePurchaseId()  {
		int pid = 0;
	//	String sql = "SELECT PurchaseId_seq.NEXTVAL FROM dual";
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QueryMapper.GENERATE_PURCHASEID_SEQUENCE);
			rst.next();
			pid = rst.getInt(1);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			try {
				throw new EnquiryException("Problem in generating product id "+ e.getMessage());
			} catch (EnquiryException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		return pid;
	}
	
	

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws EnquiryException{
		EnquiryBean enquiry= new EnquiryBean();	
		conn = DBUtil.getConnection();
		try {
			
			
			PreparedStatement preparedStatement = conn.prepareStatement(QueryMapper.RETRIVE_PURCHASE_DETAILS_WITH_PURCHASEID_QUERY);
			logger.info("connection established successfully");
			preparedStatement.setInt(1,EnquiryID);
	
			ResultSet resultSet = preparedStatement.executeQuery();
			while
				(resultSet.next()){
			//demandDraft.setTransaction_Id(resultSet.getInt("Transaction_Id"));
				enquiry.setfName(resultSet.getString(1));
				enquiry.setlName(resultSet.getString(2));
				enquiry.setContactNo(resultSet.getString(3));
				enquiry.setpLocation(resultSet.getString(4));
		
			
			logger.info("Get DemandDraft details is successfull");
			}
			
			
			
		} catch (SQLException e) {
			
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}	
		enquiry.setEnqryId(EnquiryID);
		
	
	return enquiry;
	}

}
